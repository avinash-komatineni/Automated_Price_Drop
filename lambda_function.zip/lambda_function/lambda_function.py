import boto3
from bs4 import BeautifulSoup
import requests
from datetime import datetime


# Initialize AWS clients
dynamodb = boto3.client('dynamodb')
sns = boto3.client('sns')

def lambda_handler(event, context):
    # Web scraping logic
    url="https://www.amazon.com/2021-Apple-10-2-inch-iPad-Wi-Fi/dp/B09G9FPHY6"
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")
    title_element = soup.select_one("#productTitle")
    title = title_element.text.strip() if title_element else None
    price_element = soup.select_one('span.a-offscreen')
    current_price = float(price_element.text.strip().replace('$', '')) if price_element else None

    # Fetch previous price from DynamoDB
    response = dynamodb.get_item(
        TableName='PriceHistory',
        Key={'Timestamp': {'S': 'latest'}}
    )
    if 'Item' in response:
        previous_price = float(response['Item']['Price']['N'])
    else:
        previous_price = None

 
    # Compare prices and send notification if there's a drop
    if previous_price and current_price < previous_price:
        sns.publish(
            TopicArn='arn:aws:sns:us-east-1:058264392410:PriceDrop-SNSTopic-lSajuiunEEls',
            Message=f'iPad price dropped from ${previous_price} to ${current_price}!'
        )
        notification_sent = 'Yes'
    else:
        notification_sent = 'No'

    
    # Update DynamoDB with current price and notification status
    current_timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    dynamodb.put_item(
        TableName='PriceHistory',
        Item={
            'Timestamp': {'S': current_timestamp},
            'Price': {'N': str(current_price)},
            'NotificationSent': {'S': notification_sent}
        }
    )
    dynamodb.put_item(
        TableName='PriceHistory',
        Item={
            'Timestamp': {'S': 'latest'},
            'Price': {'N': str(current_price)},
            'NotificationSent': {'S': notification_sent}
        }
    )
